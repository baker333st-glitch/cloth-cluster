"use client";

import { useState, useEffect, useCallback } from "react";
import Logo from "@/components/Logo";
import MarqueeText from "@/components/MarqueeText";
import ProductCard from "@/components/ProductCard";

interface Product {
  id: number;
  name: string;
  description: string | null;
  imageUrl: string | null;
  price: number;
  discountPrice: number | null;
  sizes: string;
  category: string | null;
  inStock: boolean;
  articleCode: string | null;
}

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortOrder, setSortOrder] = useState<"default" | "low" | "high">("default");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterStock, setFilterStock] = useState("all");
  const [showDownload, setShowDownload] = useState(false);
  const [dlPhone, setDlPhone] = useState("");
  const [dlEmail, setDlEmail] = useState("");
  const [dlMsg, setDlMsg] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);

  const fetchProducts = useCallback(async () => {
    try {
      const res = await fetch("/api/products");
      const data = await res.json();
      setProducts(Array.isArray(data) ? data : []);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const categories = ["all", ...new Set(products.map((p) => p.category || "General"))];

  let filtered = [...products];
  if (filterCategory !== "all") {
    filtered = filtered.filter((p) => (p.category || "General") === filterCategory);
  }
  if (filterStock === "instock") {
    filtered = filtered.filter((p) => p.inStock);
  } else if (filterStock === "outofstock") {
    filtered = filtered.filter((p) => !p.inStock);
  }
  if (sortOrder === "low") {
    filtered.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
  } else if (sortOrder === "high") {
    filtered.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
  }

  const handleDownload = async () => {
    if (!dlPhone || !dlEmail) {
      setDlMsg("Please enter both contact number and email");
      return;
    }
    try {
      const res = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactNumber: dlPhone, email: dlEmail }),
      });
      const data = await res.json();
      setDlMsg(data.message || data.error);
    } catch {
      setDlMsg("Error processing request");
    }
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 bg-black/90 backdrop-blur-md border-b border-skyblue/20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Logo size="text-2xl" />
          <div className="hidden md:flex items-center gap-6">
            <a href="#home" className="text-skyblue hover:text-skyblue-light transition-colors font-medium">Home</a>
            <a href="#products" className="text-gray-300 hover:text-skyblue transition-colors font-medium">Products</a>
            <a href="#branches" className="text-gray-300 hover:text-skyblue transition-colors font-medium">Branches</a>
            <a href="#contact" className="text-gray-300 hover:text-skyblue transition-colors font-medium">Contact</a>
            <button
              onClick={() => setShowDownload(true)}
              className="bg-skyblue hover:bg-skyblue-dark text-white px-4 py-2 rounded-lg font-semibold transition-colors text-sm"
            >
              📱 Download App
            </button>
            <a
              href="/admin"
              className="text-gray-500 hover:text-skyblue transition-colors text-sm"
              title="Admin Login"
            >
              🔐
            </a>
          </div>
          <button className="md:hidden text-skyblue text-2xl" onClick={() => setMobileMenu(!mobileMenu)}>
            {mobileMenu ? "✕" : "☰"}
          </button>
        </div>
        {mobileMenu && (
          <div className="md:hidden animate-slide-down bg-black/95 border-t border-skyblue/20 px-4 py-4 flex flex-col gap-3">
            <a href="#home" onClick={() => setMobileMenu(false)} className="text-skyblue font-medium py-2">Home</a>
            <a href="#products" onClick={() => setMobileMenu(false)} className="text-gray-300 font-medium py-2">Products</a>
            <a href="#branches" onClick={() => setMobileMenu(false)} className="text-gray-300 font-medium py-2">Branches</a>
            <a href="#contact" onClick={() => setMobileMenu(false)} className="text-gray-300 font-medium py-2">Contact</a>
            <button onClick={() => { setShowDownload(true); setMobileMenu(false); }} className="bg-skyblue text-white px-4 py-2 rounded-lg font-semibold text-sm">📱 Download App</button>
            <a href="/admin" className="text-gray-500 text-sm py-2">🔐 Admin</a>
          </div>
        )}
      </nav>

      {/* Marquee */}
      <MarqueeText />

      {/* Hero */}
      <section
        id="home"
        className="relative min-h-[70vh] flex items-center justify-center overflow-hidden"
        style={{
          background: `linear-gradient(135deg, rgba(0,0,0,0.85) 0%, rgba(3,105,161,0.4) 50%, rgba(0,0,0,0.85) 100%), url('https://images.pexels.com/photos/6065984/pexels-photo-6065984.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200') center/cover no-repeat`,
        }}
      >
        <div className="text-center px-4 z-10">
          <div className="flex justify-center mb-6 animate-float">
            <div className="bg-gradient-to-br from-skyblue to-skyblue-dark rounded-2xl p-4 md:p-6 animate-pulse-glow">
              <span className="text-5xl md:text-7xl font-black text-white tracking-tighter">FZ</span>
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-white mb-4 animate-fade-in-up">
            NEW LOOK <span className="text-skyblue">FASHION</span>
          </h1>
          <p className="text-xl md:text-2xl text-skyblue-light font-light mb-2 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Premium Menswear Collection
          </p>
          <p className="text-gray-400 text-lg mb-6 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            Shirts • Suits • T-Shirts • Jeans • Kurta • Ethnic Wear
          </p>
          <div className="flex flex-wrap justify-center gap-3 animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
            <a
              href="#products"
              className="bg-skyblue hover:bg-skyblue-dark text-white px-8 py-3 rounded-full font-bold text-lg transition-colors"
            >
              Shop Now
            </a>
            <a
              href="https://wa.me/916394038329?text=Hi!%20I%20want%20to%20know%20about%20your%20collection"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-full font-bold text-lg transition-colors flex items-center gap-2"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              WhatsApp
            </a>
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm text-gray-400 animate-fade-in-up" style={{ animationDelay: "0.8s" }}>
            <span className="bg-yellow-500/20 text-yellow-400 px-3 py-1 rounded-full font-semibold">🏪 Wholesale Available</span>
            <span className="bg-skyblue/20 text-skyblue px-3 py-1 rounded-full font-semibold">💳 UPI Payment</span>
            <span className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full font-semibold">📱 WhatsApp Orders</span>
          </div>
        </div>
      </section>

      {/* Second Marquee */}
      <div className="bg-gradient-to-r from-yellow-600 via-yellow-500 to-yellow-600 py-2 overflow-hidden">
        <div className="animate-marquee whitespace-nowrap">
          <span className="text-lg font-bold text-black mx-8">⚡ WHOLESALE AVAILABLE ⚡</span>
          <span className="text-lg font-bold text-black mx-8">🎉 Visit Store for More Offers! 🎉</span>
          <span className="text-lg font-bold text-black mx-8">🚫 Cash on Delivery NOT Available — WhatsApp Order Only 🚫</span>
          <span className="text-lg font-bold text-black mx-8">🏷️ Filter Products: Low to High Price 🏷️</span>
          <span className="text-lg font-bold text-black mx-8">⚡ WHOLESALE AVAILABLE ⚡</span>
        </div>
      </div>

      {/* Products Section */}
      <section id="products" className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-black text-white mb-2">
            Our <span className="text-skyblue">Collection</span>
          </h2>
          <p className="text-gray-400">Explore premium menswear at the best prices</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-8 justify-center">
          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value as "default" | "low" | "high")}
            className="bg-gray-900 text-white border border-gray-700 rounded-lg px-4 py-2 text-sm focus:border-skyblue outline-none"
          >
            <option value="default">Sort: Default</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
          </select>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-gray-900 text-white border border-gray-700 rounded-lg px-4 py-2 text-sm focus:border-skyblue outline-none"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c === "all" ? "All Categories" : c}
              </option>
            ))}
          </select>
          <select
            value={filterStock}
            onChange={(e) => setFilterStock(e.target.value)}
            className="bg-gray-900 text-white border border-gray-700 rounded-lg px-4 py-2 text-sm focus:border-skyblue outline-none"
          >
            <option value="all">All Stock</option>
            <option value="instock">In Stock</option>
            <option value="outofstock">Out of Stock</option>
          </select>
        </div>

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-12 h-12 border-4 border-skyblue border-t-transparent rounded-full animate-spin"></div>
            <p className="text-gray-400 mt-4">Loading products...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-6xl mb-4">👔</p>
            <p className="text-gray-400 text-lg">No products found. Check back soon!</p>
            <p className="text-skyblue mt-2">Visit our store for more collection</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* Branches Section */}
      <section id="branches" className="bg-gradient-to-b from-black via-gray-950 to-black py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-black text-white mb-2">
              Our <span className="text-skyblue">3 Branches</span>
            </h2>
            <p className="text-gray-400">Visit us at any of our Gorakhpur locations</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {/* Main Branch */}
            <div className="bg-gradient-to-br from-skyblue/20 to-skyblue/5 border-2 border-skyblue rounded-2xl p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-skyblue text-white text-xs font-bold px-3 py-1 rounded-bl-lg">MAIN BRANCH</div>
              <div className="text-4xl mb-4">🏬</div>
              <h3 className="text-xl font-bold text-white mb-2">NEW LOOK FASHION</h3>
              <p className="text-skyblue-light font-semibold mb-2">Main Branch - Bichhiya</p>
              <p className="text-gray-300 text-sm">📍 Bichhiya, Gorakhpur</p>
              <p className="text-gray-400 text-sm mt-1">📞 6384038329</p>
              <p className="text-yellow-400 text-xs mt-3 font-semibold">★ Flagship Store • Complete Collection</p>
            </div>
            {/* Branch 2 */}
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900 border border-gray-700 rounded-2xl p-6 hover:border-skyblue/50 transition-colors">
              <div className="text-4xl mb-4">🏪</div>
              <h3 className="text-xl font-bold text-white mb-2">NEW LOOK FASHION</h3>
              <p className="text-skyblue-light font-semibold mb-2">Branch 2</p>
              <p className="text-gray-300 text-sm">📍 Neena Thapa, Gorakhpur</p>
              <p className="text-gray-400 text-sm mt-1">📞 6384038329</p>
              <p className="text-yellow-400 text-xs mt-3 font-semibold">★ Full Range Available</p>
            </div>
            {/* Branch 3 */}
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900 border border-gray-700 rounded-2xl p-6 hover:border-skyblue/50 transition-colors">
              <div className="text-4xl mb-4">🏪</div>
              <h3 className="text-xl font-bold text-white mb-2">NEW LOOK FASHION</h3>
              <p className="text-skyblue-light font-semibold mb-2">Branch 3</p>
              <p className="text-gray-300 text-sm">📍 Jhumila Bazar, Badhahalganj</p>
              <p className="text-gray-400 text-sm mt-1">📞 6384038329</p>
              <p className="text-yellow-400 text-xs mt-3 font-semibold">★ Full Range Available</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: "🏪", title: "Wholesale", desc: "Bulk orders welcome" },
            { icon: "💳", title: "UPI Payment", desc: "Instant payment" },
            { icon: "📱", title: "WhatsApp Order", desc: "Order via chat" },
            { icon: "🏷️", title: "Best Prices", desc: "Visit store for offers" },
          ].map((f) => (
            <div key={f.title} className="bg-gray-900 border border-gray-800 rounded-xl p-4 text-center hover:border-skyblue/50 transition-colors">
              <div className="text-3xl mb-2">{f.icon}</div>
              <h4 className="text-white font-bold text-sm">{f.title}</h4>
              <p className="text-gray-400 text-xs mt-1">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Important Info */}
      <section className="bg-gradient-to-r from-red-900/30 via-red-800/20 to-red-900/30 border-y border-red-800/50 py-6">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-red-400 font-bold text-lg mb-2">⚠️ Important Notice</p>
          <p className="text-gray-300 text-sm">
            🚫 <strong>Cash on Delivery is NOT available.</strong> Orders are accepted through WhatsApp only.
            Payment via UPI. For more offers and discounts, please visit our store.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-gradient-to-b from-black to-gray-950 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-black text-white mb-6">
            Contact <span className="text-skyblue">Us</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h3 className="text-skyblue font-bold text-lg mb-4">📞 Get in Touch</h3>
              <p className="text-gray-300 mb-2">Phone: <a href="tel:6384038329" className="text-skyblue hover:underline">6384038329</a></p>
              <p className="text-gray-300 mb-4">WhatsApp: <a href="https://wa.me/916394038329" className="text-green-400 hover:underline">6394038329</a></p>
              <a
                href="https://wa.me/916394038329?text=Hi!%20I%20want%20to%20place%20an%20order"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full font-bold transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                Join WhatsApp
              </a>
            </div>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h3 className="text-skyblue font-bold text-lg mb-4">📍 Main Store</h3>
              <p className="text-white font-bold text-lg">NEW LOOK FASHION</p>
              <p className="text-gray-300 mt-2">Bichhiya, Gorakhpur</p>
              <p className="text-gray-400 text-sm mt-1">Near KMG Vatika School</p>
              <div className="mt-4 bg-skyblue/10 rounded-lg p-3">
                <p className="text-skyblue text-sm font-semibold">🏪 Wholesale Available</p>
                <p className="text-gray-400 text-xs mt-1">Contact us for bulk orders and special pricing</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 border-t border-gray-800 py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <Logo size="text-xl" />
            <div className="text-center">
              <p className="text-gray-400 text-sm">
                © 2024 NEW LOOK FASHION (newlookfz). All rights reserved.
              </p>
              <p className="text-gray-500 text-xs mt-1">
                Bichhiya • Neena Thapa Gorakhpur • Jhumila Bazar Badhahalganj
              </p>
            </div>
            <div className="flex gap-3">
              <a
                href="https://wa.me/916394038329"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-600 hover:bg-green-700 text-white p-2 rounded-full transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </a>
              <a
                href="tel:6384038329"
                className="bg-skyblue hover:bg-skyblue-dark text-white p-2 rounded-full transition-colors"
              >
                📞
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Bottom Admin Icon */}
      <div className="fixed bottom-4 right-4 z-30">
        <a
          href="/admin"
          className="bg-gray-900 border border-gray-700 hover:border-skyblue text-gray-400 hover:text-skyblue p-3 rounded-full shadow-lg transition-all flex items-center justify-center"
          title="Admin Panel"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
        </a>
      </div>

      {/* Download Modal */}
      {showDownload && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setShowDownload(false)}>
          <div className="bg-gray-900 border border-skyblue/30 rounded-2xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-white">📱 Download App</h3>
              <button onClick={() => setShowDownload(false)} className="text-gray-400 hover:text-white text-xl">✕</button>
            </div>
            <p className="text-gray-400 text-sm mb-4">Get NEW LOOK FASHION app for Phone, Tab & PC</p>
            <div className="space-y-3">
              <input
                type="tel"
                placeholder="Contact Number"
                value={dlPhone}
                onChange={(e) => setDlPhone(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-skyblue outline-none"
              />
              <input
                type="email"
                placeholder="Email Address"
                value={dlEmail}
                onChange={(e) => setDlEmail(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-skyblue outline-none"
              />
              <button
                onClick={handleDownload}
                className="w-full bg-skyblue hover:bg-skyblue-dark text-white py-3 rounded-lg font-bold transition-colors"
              >
                Get Download Link
              </button>
              {dlMsg && <p className="text-skyblue text-sm text-center">{dlMsg}</p>}
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <div className="bg-gray-800 rounded-lg p-2">
                <p className="text-2xl">📱</p>
                <p className="text-xs text-gray-400">Phone</p>
              </div>
              <div className="bg-gray-800 rounded-lg p-2">
                <p className="text-2xl">📟</p>
                <p className="text-xs text-gray-400">Tablet</p>
              </div>
              <div className="bg-gray-800 rounded-lg p-2">
                <p className="text-2xl">💻</p>
                <p className="text-xs text-gray-400">PC/Windows</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
