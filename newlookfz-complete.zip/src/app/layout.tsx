import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "NEW LOOK FASHION | Premium Menswear Store - newlookfz",
  description:
    "NEW LOOK FASHION - Premium menswear clothing shop in Gorakhpur. Shirts, Suits, T-Shirts & more. 3 branches: Bichhiya, Neena Thapa & Jhumila Bazar. Wholesale available!",
  keywords: "menswear, fashion, Gorakhpur, shirts, suits, wholesale, NEW LOOK FASHION",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-black text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
